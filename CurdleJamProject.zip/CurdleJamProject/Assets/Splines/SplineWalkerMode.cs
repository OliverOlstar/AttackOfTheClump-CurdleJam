﻿public enum SplineWalkerMode {
	Once,
	Loop,
	PingPong
}