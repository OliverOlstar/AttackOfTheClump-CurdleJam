This sample shows how to implement and register a custom InputBindingComposite.
